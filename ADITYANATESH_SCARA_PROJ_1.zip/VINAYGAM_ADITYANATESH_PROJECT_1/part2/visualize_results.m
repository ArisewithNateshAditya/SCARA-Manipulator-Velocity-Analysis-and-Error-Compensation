%plot tracking
tracking = error(1:3,:)';

figure(1)
title('error plot');
subplot(4,1,1); plot(t, pd(:,1)-tracking(:,1)); ylabel('X error');
subplot(4,1,2); plot(t, pd(:,2)-tracking(:,2)); ylabel('Y error');
subplot(4,1,3); plot(t, pd(:,3)-tracking(:,3)); ylabel('Z error');
xlabel('time')
subplot(4,1,4);
%subplot(4,1,4); plot(t, theta_d(:,1)-tracking_theta(:,1));

figure(2)
joints = q(1:4,:)';
title('joint plot');
subplot(5,1,1); plot(t, joints(:,1)); ylabel('J1');
subplot(5,1,2); plot(t, joints(:,2)); ylabel('J2');
subplot(5,1,3); plot(t, joints(:,3)); ylabel('J3');
subplot(5,1,4); plot(t, joints(:,4)); ylabel('J4');
xlabel('time');
subplot(5,1,5);