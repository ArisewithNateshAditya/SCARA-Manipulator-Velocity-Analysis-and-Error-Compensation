function finalqa=funct(q)
syms theta1 theta2 d3 theta4
j1avg = ((-pi/2)+(pi/2))/2;
j2avg = ((-pi/2)+(pi/4))/2;
j3avg=(0.25+1)/2;
j4avg=((-2*pi)+(2*pi))/2;

J1=((theta1-j1avg)/((theta1*(pi/2))-theta1*(-pi/2)))^2;
J2=((theta2-j2avg)/((theta2*(pi/4))-theta2*(-pi/2)))^2;
J3=((d3-j3avg)/((d3*1)-(d3*0.25)))^2;
J4=((theta4-j4avg)/((theta4*(2*pi))-theta4*(-2*pi)))^2;

qomega=(-0.5/(4*2))*(J1+J2+J3+J4);
qa=[diff(qomega,theta1) diff(qomega,theta2) diff(qomega,d3) diff(qomega,theta4)];
qa=double(subs(qa,[theta1 theta2 d3 theta4],[q(1) q(2) q(3) q(4)]));
finalqa= qa';
end