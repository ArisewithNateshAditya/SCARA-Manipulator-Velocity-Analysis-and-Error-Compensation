function EE= direct_kin(q)
a1=0.5;
a2=0.5;
a3=0;
a4=0;
d1=0;
d2=0;
d3=q(3);
d4=0;
theta1=q(1);
theta2=q(2);
theta3=0;
theta4=q(4);
alpha1=0;
alpha2=0;
alpha3=0;
alpha4=0;

T0=[1 0 0 0;
    0 1 0 0;
    0 0 1 1;
    0 0 0 1;]

T1=[cos(theta1) -sin(theta1)*cos(alpha1) sin(theta1)*sin(alpha1) a1*cos(theta1);
    sin(theta1) cos(theta1)*cos(alpha1) -cos(theta1)*sin(alpha1) a1*sin(theta1);
    0 sin(alpha1) cos(alpha1) d1;
    0 0 0 1;]

T2=[cos(theta2) -sin(theta2)*cos(alpha2) sin(theta2)*sin(alpha2) a2*cos(theta2);
    sin(theta2) cos(theta2)*cos(alpha2) -cos(theta2)*sin(alpha2) a2*sin(theta2);
    0 sin(alpha2) cos(alpha2) d2;
    0 0 0 1;]

T3=[cos(theta3) -sin(theta3)*cos(alpha3) sin(theta3)*sin(alpha3) a3*cos(theta3);
    sin(theta3) cos(theta3)*cos(alpha3) -cos(theta2)*sin(alpha3) a3*sin(theta3);
    0 sin(alpha3) cos(alpha3) -d3;
    0 0 0 1;]

T4=[cos(theta4) -sin(theta4)*cos(alpha4) sin(theta4)*sin(alpha4) a4*cos(theta4);
    sin(theta4) cos(theta4)*cos(alpha4) -cos(theta4)*sin(alpha4) a4*sin(theta4);
    0 sin(alpha4) cos(alpha4) d4;
    0 0 0 1;]

T00=T0;
T01=T0*T1;
T02=T01*T2;
T03=T02*T3;
T04=T03*T4;
pos = T04(1:3,4);
pos = pos';
o = theta1 + theta2 + theta4;
EE = [pos o];


end